const Alexa = require('ask-sdk-core');
const F1 = require("./helper/f1InfoClasses");

const LaunchRequestHandler = {
    canHandle(handlerInput) {
      return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
    },
    handle(handlerInput) {
      const speechText = 'Willkommen zum Formel 1 Helfer! Du kannst mich über Ergebnisse, Rennzeiten und Tabellenplätze befragen!';
  
      return handlerInput.responseBuilder
        .speak(speechText)
        .reprompt(speechText)
        .getResponse();
    }
};

const GetPodiumInfoIntentHandler = {
    canHandle(handlerInput) {
      return handlerInput.requestEnvelope.request.type === 'IntentRequest'
        && handlerInput.requestEnvelope.request.intent.name === 'GetPodiumInfo';
    },
    handle(handlerInput) {
      const speechText = "";
      var n1 = handlerInput.requestEnvelope.request.intent;
      //var n2 = handlerInput.requestEnvelope.request.intent.slots.round.value;

      speechText = n1 + " " + n2;

      /*const requestEnvelope = handlerInput;

      const year = Alexa.getSlotValue(requestEnvelope, "year");
      const round = Alexa.getSlotValue(requestEnvelope, "round");

      speechText = "Jahr ist " + year + ". Runde ist " + round + ".";*/
  

      return handlerInput.responseBuilder
        .speak(speechText)
        .getResponse();
    }
};

const ErrorHandler = {
    canHandle() {
      return true;
    },
    handle(handlerInput, error) {
      console.log(`Error handled: ${error.message}`);
  
      return handlerInput.responseBuilder
        .speak('Sorry, I can\'t understand the command. Please say again.')
        .reprompt('Sorry, I can\'t understand the command. Please say again.')
        .getResponse();
    },
};

exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        GetPodiumInfoIntentHandler
    )
    .addErrorHandler(ErrorHandler)
    .lambda();